package com.rahul;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactApplicationTests {

	@Test
	void contextLoads() {
		
		assertTrue(true);
	}

	
	@Test
	void contextLoads1() {
		
		assertTrue(true);
	}
	@Test
	void scontextLoads() {
		
		assertTrue(true);
	}
	@Test
	void ccontextLoads() {
		
		assertTrue(true);
	}
	
	@Test
	void csontextLoads() {
		
		assertTrue(true);
	}@Test
	void concxtextLoads() {
		
		assertTrue(true);
	}
}
